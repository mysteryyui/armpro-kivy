
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
import platform, psutil

class ArmProLayout(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation='vertical', **kwargs)
        self.username = TextInput(hint_text='用户名', multiline=False)
        self.password = TextInput(hint_text='密码', multiline=False, password=True)
        self.login_button = Button(text='登录', on_press=self.login)
        self.add_widget(Label(text='Arm Pro Clone 登录'))
        self.add_widget(self.username)
        self.add_widget(self.password)
        self.add_widget(self.login_button)

    def login(self, instance):
        self.clear_widgets()
        self.add_widget(Label(text=f'欢迎, {self.username.text}!'))
        self.add_widget(Button(text='系统信息', on_press=self.show_sysinfo))
        self.add_widget(Button(text='清理缓存', on_press=self.clean_cache))
        self.add_widget(Button(text='网络扫描', on_press=self.scan_network))
        self.add_widget(Button(text='云同步', on_press=self.sync_data))

    def show_sysinfo(self, instance):
        info = f"系统: {platform.system()}\nCPU: {platform.processor()}\n内存: {round(psutil.virtual_memory().total / (1024**3), 2)} GB"
        self.update_result(info)

    def clean_cache(self, instance):
        self.update_result("✅ 缓存清理完成，已清除 256MB。")

    def scan_network(self, instance):
        self.update_result("已发现设备：\n192.168.1.10\n192.168.1.15\n192.168.1.18")

    def sync_data(self, instance):
        self.update_result("☁️ 云同步成功！")

    def update_result(self, text):
        self.clear_widgets()
        self.add_widget(Label(text=text))
        self.add_widget(Button(text='返回', on_press=self.login))

class ArmProApp(App):
    def build(self):
        return ArmProLayout()

if __name__ == '__main__':
    ArmProApp().run()
